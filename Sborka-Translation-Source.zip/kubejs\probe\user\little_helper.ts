/**
 * Dialogue system for the Little Helper companion.
 * Renders an animated dialogue overlay using the Paint API.
 * Phases: 'in' (slide in) → 'write' (typewriter) → 'wait' (display) → 'out' (slide out)
 */
declare const Dialogue: {
    CONFIG: {
        /** Target X position after fade-in */
        MAX_X: number;
        /** Starting X position for fade-in/out */
        MIN_X: number;
        /** How long to wait after text is fully written (in ticks) */
        DISPLAY_TICKS: number;
        /** Vertical offset for the overlay */
        Y_OFFSET: number;
        /** Pixels per tick for movement */
        ANIM_SPEED: number;
        /** Characters per tick for typewriter effect */
        TEXT_SPEED: number;
        /** Max characters per line before wrapping */
        TEXT_WRAP_LIMIT: number;
    };

    IDS: {
        BG: string;
        BOX: string;
        TITLE: string;
        TEXT: string;
        ICON: string;
    };

    /**
     * Starts a new dialogue for a player.
     * @param player The player instance
     * @param npc Name of the NPC icon (from ftb namespace)
     * @param text The dialogue text to display
     * @param title The title/speaker name (defaults to 'Little Helper')
     */
    begin(player: Internal.Player, npc: string, text: string, title?: string): void;

    /**
     * Updates the dialogue state and renders it. Called every player tick.
     */
    update(player: Internal.Player): void;

    /**
     * Clears dialogue state and UI elements.
     */
    clear(player: Internal.Player): void;

    /**
     * Renders the current dialogue state using the Paint API.
     */
    render(player: Internal.Player, state: {
        npc: string;
        title: string;
        fullText: string;
        x: number;
        chars: number;
        wait: number;
        phase: 'in' | 'write' | 'wait' | 'out';
    }): void;

    /**
     * Word-wraps a string into lines.
     */
    wrapText(str: string, limit: number): string[];
};

/**
 * Behavior engine for the Little Helper companion.
 * Registers conditions, actions, and behaviors that are evaluated on triggers.
 */
declare const LHEngine: {
    /** Registered condition handlers, keyed by name. Conditions return true/false based on player state, context, and event data. */
    conditions: Record<string, {
        test(player: Internal.Player, conditions: object, context: object, event: object): boolean;
    }>;


    /** Registered action handlers, keyed by name. Actions perform side effects like buffs, spells, or dialogue. */
    actions: Record<string, {
        execute(player: Internal.Player, action: object, context: object, event: object): void;
    }>;

    /** Registered behaviors. Each defines a trigger, conditions to check, and actions to execute. */
    behaviors: Array<{
        id: string;
        trigger: string;
        priority?: number;
        cooldown: number;
        conditions: Record<string, any>;
        actions: Array<{ type: string; [key: string]: any }>;
    }>;


    /**
     * Registers a new condition type that can be used in behaviors.
     * The test method receives the player, condition parameters, a shared context object, and the event.
     * @param name Unique name for the condition (e.g. 'chance', 'currentHp', 'hasStages')
     * @param handler Object with a test method that returns true if the condition passes
     *
     * Example:
     * ```js
     * LHEngine.registerCondition('hasItem', {
     *   test(player, conditions, context, event) {
     *     return player.inventory.contains(conditions.item);
     *   }
     * });
     * ```
     */
    registerCondition(name: string, handler: {
        test(player: Internal.Player, conditions: object, context: object, event: object): boolean;
    }): void;

    /**
     * Registers a new action type that can be used in behaviors.
     * @param name Unique name for the action (e.g. 'buff', 'spell', 'dialogue_random')
     * @param handler Object with an execute method that performs the action
     *
     * Example:
     * ```js
     * LHEngine.registerAction('buff', {
     *   execute(player, action, context, event) {
     *     player.potionEffects.add(action.effect, action.amount, 0, false, true);
     *   }
     * });
     * ```
     */
    registerAction(name: string, handler: {
        execute(player: Internal.Player, action: object, context: object, event: object): void;
    }): void;

    /**
     * Registers an array of behavior definitions.
     * Behaviors are appended to the existing list, not replaced.
     * @param behaviorArray Array of behavior objects to register
     */
    registerBehaviors(behaviorArray: LHEngine['behaviors']): void;

    /**
     * Returns a deduplicated list of all registered behavior IDs.
     */
    getBehaviorIds(): string[];

    /**
     * Resolves a value that may be static or rank-scaled.
     * - If `amount` is a number, returns it directly.
     * - If `amount` is `{ perRank: N }`, returns `N * context.skillRank`.
     * @param amount A static number or a per-rank scaling object
     * @param context The behavior context (must contain `skillRank` for scaling)
     */
    resolveValue(amount: number | { perRank: number }, context: { skillRank?: number }): number;

    /**
     * Checks if a behavior is still on cooldown for the given player.
     * Reads from the player's persistent data (`ftblh_cooldown`).
     * @param player The player to check
     * @param id The behavior ID
     */
    isOnCooldown(player: Internal.Player, id: string): boolean;

    /**
     * Sets a cooldown for a behavior on the given player.
     * Stored in persistent data as a system time timestamp.
     * @param player The player to set cooldown for
     * @param id The behavior ID
     * @param ticks Cooldown duration in game ticks (converted to ms internally)
     */
    setCooldown(player: Internal.Player, id: string, ticks: number): void;

    /**
     * Evaluates all behaviors matching the given trigger for a player.
     * Behaviors are sorted by priority (highest first). Only the first
     * behavior whose conditions pass will execute (highest priority wins).
     * 1. Checks cooldown
     * 2. Evaluates all conditions (with shared context object)
     * 3. Executes all actions if conditions pass
     * 4. Sets the behavior's cooldown
     * 5. Stops — no further behaviors are evaluated
     *
     * @param player The player that triggered the event
     * @param trigger The trigger name (e.g. 'player_hurt', 'player_tick')
     * @param event The KubeJS event object for context
     */
    processTrigger(player: Internal.Player, trigger: string, event: object): void;

    /**
     * Checks all conditions for a behavior against the player and event.
     * Returns false if any condition fails.
     * @param player The player to check conditions for
     * @param conditions The conditions record from a behavior definition
     * @param context Shared context object passed between conditions
     * @param event The KubeJS event object
     */
    checkConditions(player: Internal.Player, conditions: Record<string, any>, context: object, event: object): boolean;

    /**
     * Executes all actions in an action array for a player.
     * @param player The player to execute actions for
     * @param actions The actions array from a behavior definition
     * @param context Shared context object from condition evaluation
     * @param event The KubeJS event object
     */
    processActions(player: Internal.Player, actions: Array<{ type: string; [key: string]: any }>, context: object, event: object): void;

    /**
     * Returns all behaviors matching a trigger, sorted by priority (highest first).
     * Does not evaluate conditions or cooldowns — useful for inspection/debugging.
     * @param trigger The trigger name to filter by
     */
    findMatchingTrigger(trigger: string): LHEngine['behaviors'];
};

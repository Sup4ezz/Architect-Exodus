---
navigation:
  parent: upgrades/upgrades-index.md
  title: "XP Upgrade"
  icon: "woot_revived:netherite_xp_upgrade"
  position: 1
item_ids:
  - woot_revived:copper_xp_upgrade
  - woot_revived:iron_xp_upgrade
  - woot_revived:gold_xp_upgrade
  - woot_revived:diamond_xp_upgrade
  - woot_revived:netherite_xp_upgrade
  - woot_revived:xp_shard
  - woot_revived:xp_splinter
---
# XP Upgrade

<Row>
  <ItemImage id="copper_xp_upgrade" scale="3"/>
  <ItemImage id="iron_xp_upgrade" scale="3"/>
  <ItemImage id="gold_xp_upgrade" scale="3"/>
  <ItemImage id="diamond_xp_upgrade" scale="3"/>
  <ItemImage id="netherite_xp_upgrade" scale="3"/>
</Row>

The XP upgrade add <ItemImage id="xp_shard" scale="0.5" /> XP Shard and <ItemImage id="xp_splinter" scale="0.5" /> XP Splinter to the drops.

The shard represent 9 XP and the splinter represent only 1 XP

## XP I Upgrade

Drop 50% of the XP

<RecipeFor id="copper_xp_upgrade" />

## XP II Upgrade

Drop 75% of the XP

<RecipeFor id="iron_xp_upgrade" />

## XP III Upgrade

Drop 100% of the XP

<RecipeFor id="gold_xp_upgrade" />

## XP IV Upgrade

Drop 125% of the XP

<RecipeFor id="diamond_xp_upgrade" />

## XP V Upgrade

Drop 150% of the XP

<RecipeFor id="netherite_xp_upgrade" />

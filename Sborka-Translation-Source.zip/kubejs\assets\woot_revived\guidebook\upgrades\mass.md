---
navigation:
  parent: upgrades/upgrades-index.md
  title: "Mass Upgrade"
  icon: "woot_revived:iron_mass_upgrade"
  position: 1
item_ids:
  - woot_revived:copper_mass_upgrade
  - woot_revived:iron_mass_upgrade
  - woot_revived:gold_mass_upgrade
  - woot_revived:diamond_mass_upgrade
  - woot_revived:netherite_mass_upgrade
---
# Mass Upgrade

<Row>
  <ItemImage id="copper_mass_upgrade" scale="3"/>
  <ItemImage id="iron_mass_upgrade" scale="3"/>
  <ItemImage id="gold_mass_upgrade" scale="3"/>
  <ItemImage id="diamond_mass_upgrade" scale="3"/>
  <ItemImage id="netherite_mass_upgrade" scale="3"/>
</Row>

The mass upgrade kill more mobs per simulation.

## Mass I Upgrade

Kill 2 mobs

<RecipeFor id="copper_mass_upgrade" />

## Mass II Upgrade

Kill 4 mobs

<RecipeFor id="iron_mass_upgrade" />

## Mass III Upgrade

Kill 6 mobs

<RecipeFor id="gold_mass_upgrade" />

## Mass IV Upgrade

Kill 8 mobs

<RecipeFor id="diamond_mass_upgrade" />

## Mass V Upgrade

Kill 10 mobs

<RecipeFor id="netherite_mass_upgrade" />
